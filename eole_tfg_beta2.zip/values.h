#ifndef VALUES_H
#define VALUES_H

#include <cstdint> // Sin esto no reconoce los uint8_t
using namespace std;

#define TITLE "EOLE Toolkit for Sensia"
#define VERSION "V.1.5.1"

#define VARIABLES_QUANTITY 3
#define MCKREGISTER "0x028"
#define OUTPUTREGISTER "0x0B0"
#define ITR "ITR"
#define IWR "IWR"

#define HEADER 0x40
#define PACKET_RESPONSE_OK 0x80
#define PACKET_RESPONSE_NOTOK 0x88

#define WRITE_COMMAND_ID 0x99
#define READ_COMMAND_ID 0x90

#define INT_TIME_ADDRESS 0x098
#define INT_PERIOD_ADDRESS 0x094
#define GPOL_ADDRESS 0x090

#define WRITE_PACKET_SIZE 12
#define READ_PACKET_SIZE 8

#define TWO_VIDEO_OUTPUTS 2
#define FOUR_VIDEO_OUTPUTS 4
#define CLK 20
#define E6 1000000

#define OPERATION (36/3.5)

typedef struct WRITE_REQUEST_PACKET {
    uint8_t write_header = HEADER;
    uint8_t write_command_id = WRITE_COMMAND_ID;
    uint32_t write_address; // (4 x uint8_t)
    uint32_t write_data; // (4 x uint8_t)
    uint16_t write_crc; // (2 x uint8_t)
}   WRITE_REQUEST_PACKET;

typedef struct READ_REQUEST_PACKET {
    uint8_t read_header = HEADER;
    uint8_t read_command_id = READ_COMMAND_ID;
    uint32_t read_address; // (4 x uint8_t)
    uint16_t read_crc; // (2 x uint8_t)
}   READ_REQUEST_PACKET;

typedef struct RESPONSE_PACKET {
    uint8_t response_header = HEADER;
    uint8_t response_status;
    uint32_t response_data; // (4 x uint8_t)
    uint16_t response_crc; // (2 x uint8_t)
}   RESPONSE_PACKET;

enum READONLYFIELDS {
    INTTIME = 0, INTPERIOD = 1, GPOL = 2, CUSTOM = 3
};

enum BITCASES {
    ZERO = 0, ONE = 1, TWO = 2
};

enum MCKDIVVALUES {
    FIRST = 2, SECOND = 4, THIRD = 8
};

enum WINDOWMODEVALUES {
    FIRSTRES = 640*512, SECONDRES = 512*512, THIRDRES = 640*480, FOURTHRES = -1
};

#endif // VALUES_H
